# RemesasBRL · Sistema de Remesas 2026

Sistema web single-page para gestión de remesas internacionales.

## Funcionalidades

- **Operadores**: BRL (Brasil), VZLA (Venezuela), EE.UU
- **Administrador**: Dashboard completo con inventario USDT, capital y reportes
- **Socios**: Julio y Paul con reportes individuales de ganancia
- **Módulos**: Remesas, Inventario USDT (FIFO), Capital & Reportes, Egresos, Préstamos, Por Cobrar, Historial, Traspasos, Configuración

## Flujo de trabajo

1. Operadores registran remesas sin tasas USDT (opcional)
2. Admin registra compras/ventas de USDT en Inventario
3. Las tasas se asignan automáticamente a remesas en orden FIFO
4. Los saldos de cuentas se actualizan automáticamente en todos los módulos

## Cuentas sincronizadas

Toda la configuración de cuentas parte de **⚙️ Configuración** como fuente única.
Los cambios se reflejan automáticamente en Inventario USDT, Capital & Reportes y Traspasos.

## Despliegue

Archivo único `index.html` — desplegable en Cloudflare Pages, GitHub Pages, o cualquier hosting estático.

Base de datos: Firebase Realtime Database (`adminbrl-default-rtdb.firebaseio.com`)

## Acceso

- **Admin**: PIN alfanumérico (configurado en ⚙️ Configuración)
- **BRL / VZLA / EE.UU**: PINs por operador
